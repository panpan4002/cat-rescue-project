using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    public Player player;
    public LevelLoader levelLoader;
    public string Scene;
    public Pedestal pedestal;
    public Animator animator;
    void Start()
    {

    }

    void Update()
    {
        if (pedestal.GetComponent<Pedestal>().activated == true)
        {
            this.animator.SetBool("ativo", true);
        }
        else
        {
            this.animator.SetBool("ativo", false);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            player.GetComponent<Player>().Portal = true;

            if (pedestal.GetComponent<Pedestal>().activated == true)
            {
                if (Input.GetKeyDown(KeyCode.W)) levelLoader.Transition(Scene);
            }
        }
    }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.CompareTag("Player"))
        {
            player.GetComponent<Player>().Portal = true;

            if (pedestal.GetComponent<Pedestal>().activated == true)
            {
                if (Input.GetKeyDown(KeyCode.W)) levelLoader.Transition(Scene);
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.CompareTag("Player")) player.GetComponent<Player>().Portal = false;
    }
}
