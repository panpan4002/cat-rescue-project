using System.Collections;
using System.Collections.Generic;
using System.Numerics;
using System.Text.RegularExpressions;
using TMPro;
using UnityEngine;

public class Gatonho : MonoBehaviour
{
    private GameObject player;
    private Player playerScript;
    private int playerIsToRight;
    private UnityEngine.Vector3 playerPos;

    private Animator gatonhoAnimator;
    private SpriteRenderer gatonhoSR;

    public float gatonhoSpeed;
    public ParticleSystem gatonhoParticulas;
    private bool particulas, particulas2;

    [Header("Dialogo")]
    public GameObject caixaDialogo;
    public TextMeshProUGUI textMesh;
    public string[] linhas,linhas2;
    public float textSpeed;
    private int index,index2;
    private bool dialogou;
    private bool hablar2;
    private bool podeHablar2;
    private bool resetDialogo2;


    void Start()
    {
        gatonhoAnimator = GetComponent<Animator>();
        gatonhoSR = GetComponent<SpriteRenderer>();

        player = GameObject.FindWithTag("Player");
        playerScript = player.GetComponent<Player>();

        dialogou = false;
        hablar2 = false;
        podeHablar2 = false;

        textMesh.text = string.Empty;
    }

    void Update()
    {

        if (UnityEngine.Vector3.Distance(transform.position, playerScript.transform.position) <= 7)
        {
            //gameObject.SetActive(true);
            gatonhoSR.enabled = true;
            particulas2 = false;
            if(!particulas) gatonhoParticulas.Play(); particulas = true;

            if (UnityEngine.Vector3.Distance(transform.position, playerScript.transform.position) <= 5 && !dialogou)
            {
                caixaDialogo.SetActive(true);
                dialogo();
            }
        }

        //else if (UnityEngine.Vector3.Distance(transform.position, playerScript.transform.position) <= 5 && !hablar2 && dialogou && podeHablar2 && resetDialogo2)
        //{
            //gameObject.SetActive(true);
           // caixaDialogo.SetActive(true);
            //resetDialogo2 = false;
            //dialogo2();

        //}

        else if(UnityEngine.Vector3.Distance(transform.position, playerScript.transform.position) >= 6)
        {
            //gameObject.SetActive(false);
            gatonhoSR.enabled = false;
            caixaDialogo.SetActive(false);
            dialogou = false;
            textMesh.text = string.Empty;
            particulas = false;
            if(!particulas2) gatonhoParticulas.Play(); particulas2 = true;
            //if (podeHablar2) resetDialogo2 = true;
        }

        flipSprite();

        playerPos = playerScript.transform.position;

        if(Input.GetKeyDown(KeyCode.Backspace))
        {
            if(textMesh.text == linhas[index])
            {
                proximaLinha();
            }

            else

            {
                StopAllCoroutines();
                textMesh.text = linhas[index];
            }
        }

        //if (Input.GetKeyDown(KeyCode.Backspace) && dialogou && podeHablar2)
        //{
          //  if (textMesh.text == linhas2[index2])
            //{
              //  proximaLinha2();
            //}

//            else
//
  //          {
    //            StopAllCoroutines();
      //          textMesh.text = linhas2[index2];
        //    }
        //}
    }

    void FixedUpdate()
    {

    }

    void LateUpdate()
    {
        
    }

    void dialogo()
    {

        dialogou = true;
        caixaDialogo.SetActive(true);
        index = 0;
        StartCoroutine(digitaLinha());
    }

    void dialogo2()
    {

        hablar2 = true;
        caixaDialogo.SetActive(true);
        index2 = 0;
        StartCoroutine(digitaLinha2());
    }

    void proximaLinha()
    {
        if(index < linhas.Length - 1)
        {
            index++;
            textMesh.text = string.Empty;
            StartCoroutine(digitaLinha());
        }

        else

        {
            podeHablar2 = true;
            caixaDialogo.SetActive(false);
        }
    }

    void proximaLinha2()
    {
        if (index2 < linhas2.Length - 1)
        {
            index2++;
            textMesh.text = string.Empty;
            StartCoroutine(digitaLinha2());
        }

        else

        {
            hablar2 = false;
            caixaDialogo.SetActive(false);
        }
    }

    IEnumerator digitaLinha()
    {
        caixaDialogo.GetComponent<Animator>().SetBool("isHablando", true);

        foreach (char c in linhas[index].ToCharArray())
        {
            textMesh.text += c;
            yield return new WaitForSeconds(textSpeed);
        }

        caixaDialogo.GetComponent<Animator>().SetBool("isHablando", false);
    }

    IEnumerator digitaLinha2()
    {
        caixaDialogo.GetComponent<Animator>().SetBool("isHablando", true);

        foreach (char c in linhas2[index2].ToCharArray())
        {
            textMesh.text += c;
            yield return new WaitForSeconds(textSpeed);
        }

        caixaDialogo.GetComponent<Animator>().SetBool("isHablando", false);
    }

    void flipSprite()
    {
        if (transform.position.x > playerScript.transform.position.x)
        {
            transform.eulerAngles = new UnityEngine.Vector2(0f, 0);
            playerIsToRight = -1;
            caixaDialogo.transform.eulerAngles = new UnityEngine.Vector2(0, 0);
        }
        else
        {
            transform.eulerAngles = new UnityEngine.Vector2(0f, 180f);
            playerIsToRight = 1;
            caixaDialogo.transform.eulerAngles = new UnityEngine.Vector2(0, 0);
        }
    }
}
