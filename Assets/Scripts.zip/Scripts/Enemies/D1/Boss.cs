using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : MonoBehaviour
{
    [Header("Components")]
    private GameObject player;
    private Player playerScript;
    private Rigidbody2D bossRB;
    private Animator animator;
    private enemy Infestantibus;

    [Header("Movement")]
    public float bossSpeed;
    private int direction;

    [Header("Combat")]
    public int meleeDamage;
    private bool canMeleeAttack;
    private float meleeAttackCDCounting;
    public float meleeAttackCDT = 2;
    private bool isMeleeAttacking;

    public int rangedDamage;
    private bool canRangeAttack;
    private float rangedAttackCDCounting;
    public float rangedAttackCDT = 8;
    private bool isRangeAttacking;
    public GameObject projectile;
    public GameObject projectileShooter;
    //private GameObject instantiatedProjectile;

    private Vector2 playerPos = new Vector2(0, 0);

    [Header("Animation")]
    private bool isDying;


    void Start()
    {
        Infestantibus = GetComponent<enemy>();
        player = GameObject.FindWithTag("Player");
        playerScript = player.GetComponent<Player>();
        bossRB = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        Physics2D.IgnoreCollision(playerScript.GetComponent<CapsuleCollider2D>(), GetComponent<BoxCollider2D>(), true);
        Physics2D.IgnoreCollision(playerScript.GetComponent<CapsuleCollider2D>(), GetComponent<CapsuleCollider2D>(), true);
    }

    void Update()
    {
        playerPos = playerScript.transform.position;
        if (playerPos.x > transform.position.x && isRangeAttacking == false)
        {
            transform.eulerAngles = new Vector2(0f, 180f);
            direction = 1;
        }
        else if (isRangeAttacking == false)
        {
            transform.eulerAngles = new Vector2(0f, 0);
            direction = -1;
        }

        CD();

        //if (Infestantibus.isDead == true) Destroy(gameObject);

        if(!Infestantibus.isDead)
        {
            if (Vector2.Distance(playerPos, transform.position) <= 4 && canMeleeAttack)
            {
                meleeAttack();
            }

            if (Vector2.Distance(playerPos, transform.position) <= 5 && canRangeAttack)
            {
                StartCoroutine(rangedAttack());
                //instantiatedProjectile.transform.position += transform.forward * 2;
            }
        }

        anim();
    }

    private void FixedUpdate()
    {
        if(!Infestantibus.isDead && Vector2.Distance(playerPos, transform.position) > 4 && Vector2.Distance(playerPos, transform.position) < 10 && !isRangeAttacking)
        {
            followPlayer();
        }
    }

    void LateUpdate()
    {
        stopAnim();
    }

    void stopAnim()
    {
        if (isDying) isDying = false; Debug.Log("paro o sexo");
    }

    void anim()
    {
        if (Infestantibus.isDead) isDying = true;

        if (isDying) animator.SetTrigger("deathAnim"); Debug.Log("sexo");
    }

    void CD()
    {
        if (!canMeleeAttack)
        {
            meleeAttackCDCounting += Time.deltaTime;
            if (meleeAttackCDCounting >= meleeAttackCDT)
            {
                meleeAttackCDCounting = 0;
                canMeleeAttack = true;
            }
        }

        if (!canRangeAttack)
        {
            rangedAttackCDCounting += Time.deltaTime;
            if (rangedAttackCDCounting >= rangedAttackCDT)
            {
                rangedAttackCDCounting = 0;
                canRangeAttack = true;
            }
        }
    }

    void meleeAttack()
    {
        playerScript.playerTakeDamage(meleeDamage);
        canMeleeAttack = false;
    }

    IEnumerator rangedAttack()
    {
        isRangeAttacking = true;
        canRangeAttack = false;
        yield return new WaitForSeconds(.3f);
        GameObject instantiatedProjectile1 = Instantiate(projectile, projectileShooter.transform.position, transform.rotation);
        yield return new WaitForSeconds(.3f);
        GameObject instantiatedProjectile2 = Instantiate(projectile, projectileShooter.transform.position, transform.rotation);
        yield return new WaitForSeconds(.3f);
        GameObject instantiatedProjectile3 = Instantiate(projectile, projectileShooter.transform.position, transform.rotation);
        yield return new WaitForSeconds(.3f);
        GameObject instantiatedProjectile4 = Instantiate(projectile, projectileShooter.transform.position, transform.rotation);
        yield return new WaitForSeconds(.3f);
        GameObject instantiatedProjectile5 = Instantiate(projectile, projectileShooter.transform.position, transform.rotation);
        isRangeAttacking = false;
    }

    void followPlayer()
    {
        Vector2 speedRB = bossRB.velocity;
        speedRB.x = bossSpeed * direction;
        bossRB.velocity = speedRB;
    }
}
